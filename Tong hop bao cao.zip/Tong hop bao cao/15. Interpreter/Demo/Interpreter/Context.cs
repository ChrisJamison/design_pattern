﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interpreter
{
    class Context
    {
        public string input;
        public int output;
        public Context() { }
        public Context(string input)
        {
            this.input = input;
        }
    }
}
