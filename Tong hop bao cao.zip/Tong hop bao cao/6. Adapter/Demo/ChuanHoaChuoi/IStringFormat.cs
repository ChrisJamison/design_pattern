﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChuanHoaChuoi
{
    public abstract class IStringFormat
    {
        public abstract List<string> FormatString(List<string> listString);
    }
}
