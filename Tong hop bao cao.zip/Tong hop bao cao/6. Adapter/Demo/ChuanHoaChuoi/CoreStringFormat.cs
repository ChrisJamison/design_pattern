﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChuanHoaChuoi
{
    public class CoreStringFormat
    {
        public string Format(string str)
        {
            return str.Trim();
        }
    }
}
